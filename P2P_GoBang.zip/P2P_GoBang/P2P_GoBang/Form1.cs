﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net.PeerToPeer;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace P2P_GoBang
{
    public partial class Form1 : Form
    {
        int Count = 0;//等待用户次数
        PeerNameRegistration[] PeerNameRegister = new PeerNameRegistration[1];//暂时注册只能注册1个

        private string myip = null;
        private string myport = null;

        private List<User> userList = new List<User>();

        private string ServerIP;

        private int ServerPort;
        private TcpListener myListener;
        private TcpClient client;

        private bool isButton4Clicked = false;

        private bool isPanelClicked = false;



        private BinaryReader br;
        private BinaryWriter bw;



        //五子棋
        private bool start = false;     // 游戏是否开始  false不开始，start开始

        private bool ChessCheck = false;     // 白子黑子回合，true 黑子  黑子给客户端，白子给服务端

        private const int size = 15;     // 棋盘大小

        private int[,] CheckBoard = new int[size, size];     // 棋盘点位数组

        string receiveString = null;       //接收信息

        private string chess = "1";        //1表示该客户端下棋， 0表示该服务端下棋

        private int x = 0;                 //客户端，服务端下子的x坐标

        private int y = 0;                 //客户端，服务端下子的y坐标
        
        private string x2 = "";          //传递坐标所接收到的值 x
        
        private string y2 = "";           //传递坐标所接收到的值 y
        
        private string cd = null;                  //接收到传过来的值
        
        private string win = null;         //判断谁赢


        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls=false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            initializeGame();                      // 调用初始化游戏
            this.Width = Checkerboard_Size.FormWidth;       // 设置窗口宽度
            this.Height = Checkerboard_Size.FormHeight;     // 设置窗口高度
            this.Location = new Point(400, 75);     // 设置窗口



            //获取本机IP地址
            IPAddress ip = new System.Net.IPAddress(Dns.GetHostByName(Dns.GetHostName()).AddressList[0].Address);
            myip = ip.ToString();
            //设置端口号,端口号随即产生
            int port = new Random().Next(10001, 15000);//10000用来当服务器端口
            myport = port.ToString();


        }

        //初始化五子棋
        private void initializeGame()
        {
            // 棋盘点位数组 重置为0
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    CheckBoard[i, j] = 0;
                }
            }
            start = false;                         // 未开始，在连接成功后变为true
                                                  
            button4.Visible = true;                // 显示'开始游戏'按钮
          
          
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = panel1.CreateGraphics();      // 创建面板画布
            Chessboard.DrawCB(g);                      // 调用画棋盘方法
            Chess.ReDrawC(panel1, CheckBoard);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Thread at = new Thread(Await_User);
            at.Start();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Thread swt = new Thread(Stop_Wating);
        }



        private void button3_Click(object sender, EventArgs e)
        {
            Thread st = new Thread(Search_User);
            st.Start();

        }

        private void listBox1_MouseClick(object sender, MouseEventArgs e)
        {
            //选择对手
            Thread ss = new Thread(Select_an_Opponent);
            ss.Start();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            isButton4Clicked = true;

            //选择和谁下
            Thread thread = new Thread(Judgewho);
            thread.Start();


        }

        //点击开始后，显示下棋顺序

        private void Judgewho()
        {

            try
            {
                if (start == false)
                {
                    MessageBox.Show("请先选择对手再开始游戏！", "提示");
                    return;
                }
                // 开始
                //客户端显示顺序
                else
                {
                    label2.Text = "对局开始。";
                    // 黑子回合 客户端
                    if ("1".Equals(chess)&& ChessCheck)
                    {
                        label3.Text = "落子顺序：我下";                 // 提示文本改为"黑子回合"
                        panel1.Invalidate();                  // 重绘面板"棋盘
                    }
                
                    // 白子回合 服务端
                    else if ("0".Equals(chess)&& !ChessCheck)
                    {
                        label3.Text = "落子顺序：我下";                 // 提示文本改为"黑子回合"
                        panel1.Invalidate();                  // 重绘面板"棋盘
                    }
                    else
                    {
                        //服务端显示顺序
                        label3.Text = "落子顺序：对方下";
                        panel1.Invalidate();

                    }

                }
            }
            catch { }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            isPanelClicked = true;
            Thread thread = new Thread(PlayChessThread);
            thread.Start(new object[] { sender, e });
        }

        private void PlayChessThread(object state)
        {
            object[] args = (object[])state;
            PlayChess(args[0], (MouseEventArgs)args[1]);
        }



        private void PlayChess(object sender, MouseEventArgs e)
        {


            // 判断游戏是否开始
            if (start&&isButton4Clicked)
            {
                int Judgment = 0;

                //客户端点击显示棋子，服务端禁止点击
                if ("1".Equals(chess)&&"落子顺序：我下".Equals(label3.Text))
                {
                    //客户端可以下
                    int PlacementX = e.X / Checkerboard_Size.CBoardGap;      // 求鼠标点击的X方向的第几个点位
                    int PlacementY = e.Y / Checkerboard_Size.CBoardGap;      // 求鼠标点击的Y方向的第几个点位

                    label4.Text = "位置：X: "+PlacementX;
                    label5.Text ="位置：Y: "+PlacementY;

                    x = PlacementX;
                    y = PlacementY;

                    try
                    {
                        // 判断此位置是否为空
                        if (CheckBoard[PlacementX, PlacementY] != 0)
                        {
                            MessageBox.Show("请不要重复落子。", "警告");                                 // 此位置有棋子
                            return;
                        }


                        ChessCheck = true;

                        CheckBoard[PlacementX, PlacementY] = 1; // 黑子回合
                        Judgment = 1;                           // 切换为判断黑子
                        Chess.DrawC(panel1, ChessCheck, PlacementX, PlacementY);  // 画棋子
                        label3.Text = "落子顺序：对方下";             // 提示文本改为"白子回合"
                        chess = "1";

                        bw.Write(x+","+y+","+chess);



                        // 胜利判断
                        if (WinJudgment.ChessJudgment(CheckBoard, Judgment))
                        {
                            // 判断黑子还是白子胜利
                            if (Judgment == 1)
                            {
                                MessageBox.Show("五连珠，黑胜！", "胜利提示");    // 提示黑胜
                                start = false;
                                label2.Text = "对战结束";
                                label3.Text = "对战结束";
                                label6.Text = "结果：黑胜";
                                bw.Write("win");
                               
                            }
                            
                            initializeGame();                      // 调用初始化游戏
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("请不要将棋子下在棋盘外。", "警告");
                    }                            // 防止鼠标点击边界，导致数组越界
                }

                else if ("0".Equals(chess)&&"落子顺序：我下".Equals(label3.Text))
                {
                    //服务端可以下
                    int PlacementX = e.X / Checkerboard_Size.CBoardGap;      // 求鼠标点击的X方向的第几个点位
                    int PlacementY = e.Y / Checkerboard_Size.CBoardGap;      // 求鼠标点击的Y方向的第几个点位
                    label4.Text = "X: "+PlacementX;
                    label5.Text ="Y: "+PlacementY;

                    x = PlacementX;
                    y = PlacementY;



                    try
                    {
                        // 判断此位置是否为空
                        if (CheckBoard[PlacementX, PlacementY] != 0)
                        {
                            MessageBox.Show("请不要重复落子。", "警告");                                 // 此位置有棋子
                            return;
                        }

                      
                        ChessCheck = false;

                        CheckBoard[PlacementX, PlacementY] = 2; // 白子回合
                        Judgment = 2;                           // 切换为判断
                        Chess.DrawC(panel1, ChessCheck, PlacementX, PlacementY);  // 画棋子
                        label3.Text = "落子顺序：对方下";             // 提示文本改为"黑子回合"
                        chess = "1";
                        userList[0].bw.Write(x+","+y+","+chess);

                        // 胜利判断
                        if (WinJudgment.ChessJudgment(CheckBoard, Judgment))
                        {
                            // 判断黑子还是白子胜利
                            if (Judgment != 1)
                            {
                                MessageBox.Show("五连珠，白胜！", "胜利提示");    // 提示白胜
                                start = false;
                               User cli =  userList[0];
                                label2.Text = "对战结束";
                                label3.Text = "对战结束";
                                label6.Text = "结果：白胜";
                                cli.bw.Write("win");
                                
                            }
                           
                            initializeGame();                      // 调用初始化游戏
                        }


                    }
                    catch (Exception)
                    {
                        MessageBox.Show("请不要将棋子下在棋盘外。", "警告");         // 防止鼠标点击边界，导致数组越界
                    }                           
                }
                else
                {
                    MessageBox.Show("对方回合", "提示");
                    return;
                }
            }
            else
            {
                MessageBox.Show("请先开始游戏！", "提示");      // 提示开始游戏
            }
        }




        //等待用户
        private void Await_User()
        {
            listBox1.Items.Clear();
            //将资源名注册到云中
            //创建非安全类型的PeerName对象
            PeerName peername = new PeerName("P2P_GoBang", PeerNameType.Unsecured);
            //用指定的名称和端口号初始化 PeerNameRegistration 类的新实例
            PeerNameRegister[Count] = new PeerNameRegistration(peername, Convert.ToInt32(myport));
            PeerNameRegister[Count].Comment = peername.ToString();
            PeerNameRegister[Count].Data = Encoding.UTF8.GetBytes(String.Format("{0}", DateTime.Now.ToString()));
            //因为ipv4不支持全局云，所以默认使用默认云，不需要进行设置

            //完成注册
            PeerNameRegister[Count].Start();

            //监听
            SetServerIPAndPort();
            IPAddress ip = IPAddress.Parse(ServerIP);
            myListener = new TcpListener(ip, ServerPort);
            myListener.Start();

            //连接成功后添加User
            Thread at = new Thread(ListenClientConnect);
            at.Start();


        }

        //停止等待
        private void Stop_Wating()
        {
            PeerNameRegister[Count].Stop();
            listBox1.Items.RemoveAt(Count);
            myListener.Stop();
        }

        //搜索用户
        private void Search_User()
        {
            PeerName SearchName = new PeerName("P2P_GoBang", PeerNameType.Unsecured);
            PeerNameResolver Resolver = new PeerNameResolver();
            //获取PeerNameRecord集合
            PeerNameRecordCollection collection = Resolver.Resolve(SearchName);
            //遍历PeerNameRecord集合
            foreach (PeerNameRecord record in collection)
            {
                foreach (IPEndPoint iep in record.EndPointCollection)
                {
                    if (iep.AddressFamily.Equals(AddressFamily.InterNetwork))
                    {
                        listBox1.Items.Add((IPEndPoint)iep);
                    }
                }
            }

        }


        //设置服务器ip和port
        private void SetServerIPAndPort()
        {
            ServerIP = "192.168.1.1"; //设定IP=192.168.1.1
            ServerPort = 10000; //设定port=10000
        }

        //选择对手
        private void Select_an_Opponent()
        {
            if (listBox1.SelectedIndex != -1)
            {
                //开始连接
                Thread tt = new Thread(ClientConnect);
                tt.Start();
            }
            else
            {
                MessageBox.Show("请先在【当前在线】中选择一个");
            }
        }


        //接收连接

        private void ListenClientConnect()
        {
            while (true)
            {
                client = myListener.AcceptTcpClient();
                MessageBox.Show("匹配成功！","提示");
                //接收客户端连接，接收该客户端发来的信息；
                User user = new User(client);
                userList.Add(user);

                start = true;
                //发送消息
                ServerSendData();

                Thread thread = new Thread(ServerReceiveData);
                thread.Start();

            }

        }

        private void ClientConnect()
        {
            try
            {
                SetServerIPAndPort();

                client = new TcpClient();
                client.Connect(IPAddress.Parse(ServerIP), ServerPort);
                MessageBox.Show("匹配成功！", "提示");
                User user = new User(client);
                userList.Add(user);
                start = true;

                //获取网络流
                NetworkStream networkStream = client.GetStream();
                //将网络流作为二进制读写对象
                br = new BinaryReader(networkStream);
                bw = new BinaryWriter(networkStream);

                //连接成功后，接收来自服务端的信息
                Thread clientreceive = new Thread(ClientReceiveData);
                clientreceive.Start();

            }

            catch (Exception ex)
            {
                MessageBox.Show("连接失败，原因：" + ex.Message);
                return;
            }
        }
        //发送消息（服务端）

        private void ServerSendData()
        {
            try
            {

                User Server = new User(userList[0].client);
                Server.bw.Write("你下!:11");
                Server.bw.Flush();
            }
            catch
            {
                MessageBox.Show("服务器向客户端发送信息失败！");
            }
        }

        //接收客户端的消息（服务端）
        private void ServerReceiveData()
        {
            User Client = userList[0];
            while (true)
            {
                try
                {
                    receiveString = Client.br.ReadString();
                    if ("win".Equals(receiveString))
                    {
                        MessageBox.Show("五连珠，黑胜！", "胜利提示");
                        start = false;
                        label3.Text = "对战结束";
                        label2.Text = "对战结束";
                        label4.Text = "位置X:";
                        label5.Text = "位置Y:";
                        label6.Text = "结果：黑胜";
                        initializeGame();                      // 调用初始化游戏
                       

                    }
                    //接收到的信息x,y,chess
                    isButton4Clicked = true;
                    string[] s = receiveString.Split(',');
                    x2 = s[0];
                    y2 = s[1];
                    chess = s[2];

                    //判断是否该我下棋，当x2,y2为空时，说明客户端还没下棋。服务端还不能下
                    if ("".Equals(x2)&&"".Equals(y2))
                    {
                        label3.Text = "落子顺序：对方下";
                    }
                    else
                    {
                        int Judgment = 0;
                        int xx = int.Parse(x2);
                        int yy = int.Parse(y2);
                        //有坐标后，画黑子，
                        if ("1".Equals(chess))
                        {
                            ChessCheck = true;

                            CheckBoard[xx, yy] = 1; // 黑子回合
                            Judgment = 1;                           // 切换为判断
                            Chess.DrawC(panel1, ChessCheck, xx, yy);  // 画棋子
                            chess = "0";
                            label3.Text = "落子顺序：我下";
                        }
                        else
                        {
                        }
                    }
                }
                catch
                {
                }
            }
        }

        //接收服务端消息（客户端） 
        private void ClientReceiveData()
        {
            while (true)
            {
                try
                {
                    receiveString = br.ReadString();
                    if ("win".Equals(receiveString))
                    {
                        MessageBox.Show("五连珠，白胜！", "胜利提示");    // 提示白胜
                        start = false;
                        label2.Text = "对战结束";
                        label4.Text = "位置X:";
                        label5.Text = "位置Y:";
                        label6.Text = "结果：白胜";
                        label3.Text = "对战结束";
                        initializeGame();                      // 调用初始化游戏
                       
                    }

                    char ck = receiveString[receiveString.Length-2];
                    if (ck == '1') {
                        ChessCheck = true;
                    }
                    //接收到的信息x,y,chess
                    string[] s = receiveString.Split(',');
                    x2 = s[0];
                    y2 = s[1];
                    chess = s[2];

                    //判断是否该我下棋，当x2,y2为空时，说明客户端还没下棋。服务端还不能下
                    if ("".Equals(x2)&&"".Equals(y2))
                    {
                        label3.Text = "落子顺序：";
                    }
                    else
                    {
                        int Judgment = 0;
                        int xx = int.Parse(x2);
                        int yy = int.Parse(y2);
                        //有坐标后，画白子，
                        if ("1".Equals(chess))
                        {
                            ChessCheck = false;

                            CheckBoard[xx, yy] = 2; // 白子回合
                            Judgment = 2;                           // 切换为判断
                            Chess.DrawC(panel1, ChessCheck, xx, yy);  // 画棋子
                            chess = "1";
                            label3.Text = "落子顺序：我下";
                        }
                        else { }
                    }
                }
                catch
                {
                }
            }
        }
    }
}
